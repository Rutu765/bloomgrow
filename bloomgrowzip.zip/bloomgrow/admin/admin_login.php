<?php
session_start();
$conn=mysqli_connect("localhost","root","","bloom_grow");
if($_POST){
$u=$_POST['username'];
$p=md5($_POST['password']);
$q=mysqli_query($conn,"SELECT * FROM admin WHERE username='$u' AND password='$p'");
if(mysqli_num_rows($q)){
$_SESSION['admin']=true;
header("Location: dashboard.php");
}
}
?>
<form method="post">
<h2>Admin Login</h2>
<input name="username">
<input type="password" name="password">
<button>Login</button>
</form>
