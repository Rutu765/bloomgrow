<?php include 'header.php'; ?>

<h2>Admin Dashboard</h2>

<h3>Orders</h3>
<table border="1" cellpadding="10">
<tr>
<th>Order ID</th>
<th>User ID</th>
<th>Total</th>
<th>Status</th>
<th>Date</th>
</tr>

<?php
$o = mysqli_query($conn,"SELECT * FROM orders");
while($row=mysqli_fetch_assoc($o)):
?>
<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['user_id']; ?></td>
<td>₹<?php echo $row['total']; ?></td>
<td><?php echo $row['status']; ?></td>
<td><?php echo $row['created_at']; ?></td>
</tr>
<?php endwhile; ?>
</table>

<br>
<a href="logout.php">Logout</a>

</body>