<?php
session_start();
include('../config.php');


$result = mysqli_query($conn, "SELECT * FROM orders ORDER BY order_date DESC");

$totalSalesQuery = mysqli_query($conn, "SELECT SUM(total_amount) AS total_revenue FROM orders WHERE status='Paid'");
$totalSales = mysqli_fetch_assoc($totalSalesQuery);


$totalOrdersQuery = mysqli_query($conn, "SELECT COUNT(order_id) AS total_orders FROM orders");
$totalOrders = mysqli_fetch_assoc($totalOrdersQuery);
?>

<!DOCTYPE html>
<html>
<head>
<title>BloomGrow Sales Report</title>

<style>
body{
font-family: Arial;
background:#f4f4f4;
text-align:center;
}

table{
margin:auto;
border-collapse:collapse;
width:80%;
background:white;
}

th,td{
padding:10px;
border:1px solid #ccc;
}

th{
background:#4CAF50;
color:white;
}

h2{
color:#333;
}

.summary{
margin:20px;
font-size:18px;
}
</style>

</head>

<body>

<h2>BloomGrow Sales Report</h2>

<div class="summary">
<p><b>Total Orders:</b> <?php echo $totalOrders['total_orders']; ?></p>
<p><b>Total Revenue:</b> ₹<?php echo $totalSales['total_revenue']; ?></p>
</div>

<table>

<tr>
<th>Order ID</th>
<th>User Email</th>
<th>Total Amount</th>
<th>Order Date</th>
<th>Status</th>
</tr>

<?php
while($row = mysqli_fetch_assoc($result))
{
?>

<tr>
<td><?php echo $row['order_id']; ?></td>
<td><?php echo $row['user_email']; ?></td>
<td>₹<?php echo $row['total_amount']; ?></td>
<td><?php echo $row['order_date']; ?></td>
<td><?php echo $row['status']; ?></td>
</tr>

<?php
}
?>

</table>

</body>
</html>