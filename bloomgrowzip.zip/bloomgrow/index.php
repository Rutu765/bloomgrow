<?php
include 'config.php';
?>
<!DOCTYPE html>
<html>
<head>
<title>Bloom & Grow Nursery</title>
<link rel="stylesheet" href="assets/css/style.css">
<style>
.products{
  display:flex;
  gap:20px;
  flex-wrap:wrap;
}
.product{
  border:1px solid #ccc;
  padding:15px;
  width:220px;
  text-align:center;
}
.product img{
  width:100%;
  height:180px;
  object-fit:cover;
}
</style>
</head>
<body>

<header>
<h1>🌸 Bloom & Grow Nursery</h1>
<nav>
<a href="about.php">About Us</a>
<a href="cart.php">🛒 Cart</a>
<?php if(isset($_SESSION['user'])): ?>
<a href="logout.php">Logout</a>
<?php else: ?>
<a href="login.php">Login</a>
<a href="register.php">Register</a>
<?php endif; ?>
</nav>
</header>

<h2>Bouquets</h2>
<div class="products">
<?php
$q1 = mysqli_query($conn,"SELECT * FROM products WHERE category='bouquet'");
while($row = mysqli_fetch_assoc($q1)){
?>
<div class="product">
  <img src="images/<?php echo $row['image']; ?>" alt="">
  <h3><?php echo $row['product_name'] ?? 'No Name'; ?></h3>
  <p>₹<?php echo $row['price']; ?></p>
  <a href="add_to_cart.php?id=<?php echo $row['product_id']; ?>">Add to Cart</a>
</div>
 
<?php } ?>
</div>

<hr>

<h2>Plants</h2>
<div class="products">
<?php
$q2 = mysqli_query($conn,"SELECT * FROM products WHERE category='plant'");
while($row = mysqli_fetch_assoc($q2)){
?>
<div class="product">
  <img src="images/<?php echo $row['image']; ?>" alt="">
  <h3><?php echo $row['product_name'] ?? 'No Name'; ?></h3>
  <p>₹<?php echo $row['price']; ?></p>
  <a href="add_to_cart.php?id=<?php echo $row['product_id']; ?>">Add to Cart</a>
</div>
 
<?php } ?>
</div>

<footer>
  <h3>🌸 Bloom & Grow Nursery</h3>
  <p>Fresh Bouquets & Healthy Plants Delivered with Love</p>
  <p>📞 +91 98765 43210</p>
  <p>✉️ bloomhaven@gmail.com</p>
  <p>📍 Pune</p>
</footer>

</body>
</html>
