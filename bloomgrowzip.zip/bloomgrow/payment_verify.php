<?php
include 'config.php';

if(!isset($_SESSION['user'])) header("Location: login.php");

$uid = $_SESSION['user'];
$amt = $_POST['amount'];
$method = $_POST['payment_method'];  

mysqli_query($conn, "INSERT INTO orders(user_id, total, payment_id, payment_method, status)
VALUES($uid, $amt, 'DEMO_PAYMENT', '$method', 'Paid')");

unset($_SESSION['cart']);

header("Location: order_success.php");
exit;