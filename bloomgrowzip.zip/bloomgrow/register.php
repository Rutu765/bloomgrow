<?php
include 'config.php';

if($_POST){

    $p = password_hash($_POST['password'], PASSWORD_DEFAULT);

    mysqli_query($conn,"INSERT INTO users(name,email,password)
    VALUES('$_POST[name]','$_POST[email]','$p')");

    header("Location: login.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Register</title>

<style>

body{
    margin:0;
    padding:0;

    font-family: Arial, Helvetica, sans-serif;


    background-image: url('images/bg.png');

    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;

    height:100vh;
}

.register-box{

    width:350px;

    background: rgba(255,255,255,0.9);

    padding:30px;

    border-radius:12px;

    position:absolute;

    top:50%;
    left:50%;

    transform:translate(-50%,-50%);

    box-shadow: 0 0 15px rgba(0,0,0,0.3);
}

h2{
    text-align:center;
    margin-bottom:20px;
}

input{

    width:100%;

    padding:12px;

    margin-top:10px;

    border:1px solid #ccc;

    border-radius:5px;

    font-size:15px;
}


button{

    width:100%;

    padding:12px;

    margin-top:20px;

    background:#28a745;

    color:white;

    border:none;

    border-radius:5px;

    font-size:16px;

    cursor:pointer;
}

button:hover{
    background:#218838;
}

</style>

</head>

<body>

<div class="register-box">

<h2>User Register</h2>

<form method="post">

<input type="text" name="name" placeholder="Name" required>

<br><br>

<input type="email" name="email" placeholder="Email" required>

<br><br>

<input type="password" name="password" placeholder="Password" required>

<br><br>

<button type="submit">Register</button>

</form>

</div>

</body>
</html>