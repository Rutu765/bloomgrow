<?php
include 'config.php';

$error = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $email = $_POST['email'];
    $pass  = $_POST['password'];

    $q = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");

    if(mysqli_num_rows($q) == 1){

        $u = mysqli_fetch_assoc($q);

        if(password_verify($pass, $u['password'])){

            $_SESSION['user'] = $u['id'];

            header("Location: index.php");
            exit;

        } else {

            $error = "❌ Invalid password";
        }

    } else {

        $error = "❌ Email not registered";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Login</title>

<style>

body{
    margin:0;
    padding:0;

    background-image: url('images/bg.png');

    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;

    height:100vh;
    font-family: Arial;
}

.login-box{

    width:300px;
    background: rgba(255,255,255,0.9);

    padding:30px;
    border-radius:10px;

    position:absolute;
    top:50%;
    left:50%;

    transform:translate(-50%,-50%);
}

input{

    width:100%;
    padding:10px;
    margin-top:10px;
}

button{

    margin-top:15px;
    padding:10px;
    width:100%;

    background:green;
    color:white;

    border:none;
    cursor:pointer;
}

button:hover{
    background:darkgreen;
}

.error{
    color:red;
}

</style>

</head>

<body>

<div class="login-box">

<h2>User Login</h2>

<form method="post">

<input type="email" name="email" placeholder="Email" required>

<br><br>

<input type="password" name="password" placeholder="Password" required>

<br><br>

<button type="submit">Login</button>

</form>

<p class="error">
<?php echo $error; ?>
</p>

</div>

</body>
</html>