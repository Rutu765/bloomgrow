<?php
include 'config.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$total = 0;

if (!empty($_SESSION['cart'])) {

    foreach ($_SESSION['cart'] as $id => $qty) {

        $result = mysqli_query(
            $conn,
            "SELECT price FROM products WHERE product_id = $id"
        );

        $p = mysqli_fetch_assoc($result);

        if (!$p) continue;

        $total += $p['price'] * $qty;
    }

}

$_SESSION['total'] = $total;
?>

<body background="images/bag.jpg"> 

<h1 style="color:white;" align="center">Checkout</h1></br>

<h2><p style="color:white;" ><strong>Total Amount:</strong> ₹<?php echo $total; ?></p></h2>

<form method="post" action="payment_process.php" onsubmit="return validateCard()">

    <input type="hidden" name="amount" value="<?php echo $total; ?>">

    <h3  style="color:white;">Payment Details</h3>

    <input type="text" name="card_no" id="card_no"
           placeholder="Card Number" maxlength="16" required>

    <input type="text" name="expiry"
           placeholder="MM/YYYY" required>

    <input type="password" name="cvv"
           placeholder="CVV" maxlength="3" required>

    <br><br>

    <button type="submit">Pay Now</button>

</form>

<script>
function validateCard(){
  let card = document.getElementById("card_no").value;
  if(card.length != 16){
    alert("Enter valid 16-digit card number");
    return false;
  }
  return true;
}
</script>

</body>