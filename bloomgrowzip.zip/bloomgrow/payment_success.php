<!DOCTYPE html>
<html>
<head>
<title>Payment Successful</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>

<body background="images/bg.png">

<div style="padding:40px;text-align:center;">
  <h2>✅ Payment Successful</h2>
  <p>Your payment has been processed successfully.</p>

  <a href="order_success.php">
    <button>Continue</button>
  </a>
</div>

</body>
</html>