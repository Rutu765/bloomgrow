<!DOCTYPE html>
<html>
<head>
<title>About Us - Bloom & Grow Nursery</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<header>
  <h1>🌸 Bloom & Grow Nursery</h1>
  <nav>
    <a href="index.php">Home</a>
    <a href="cart.php">Cart</a>
  </nav>
</header>

<div style="padding:30px;">
  <h2>About Us</h2>
  <p>
    Bloom Haven is an online bouquet and nursery plant shop dedicated to
    spreading happiness through flowers and greenery.
  </p>
  <p>
    We provide fresh bouquets, customized floral arrangements, and healthy
    indoor plants at affordable prices.
  </p>
  <p>
    Our mission is to make every occasion special with nature’s beauty 🌿🌸
  </p>
</div>

</body>
</html>
