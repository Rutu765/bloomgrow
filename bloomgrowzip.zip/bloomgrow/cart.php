<?php include 'config.php'; ?>

<!DOCTYPE html>
<html>
<head>
<title>Your Cart</title>

<style>

body{
    margin:0;
    padding:0;
    font-family: Arial;

 
    background-image: url('images/bg.png');

    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    background-attachment: fixed;

    min-height:100vh;
}


.cart-box{
    width:60%;
    margin:50px auto;
    background: rgba(255,255,255,0.9);
    padding:20px;
    border-radius:10px;
    box-shadow:0 0 10px rgba(0,0,0,0.3);
}


button{
    background:green;
    color:white;
    padding:10px 20px;
    border:none;
    cursor:pointer;
    border-radius:5px;
}

button:hover{
    background:darkgreen;
}

h2{
    text-align:center;
}

h3{
    color:green;
}

</style>

</head>

<body>

<div class="cart-box">

<h2>Your Cart</h2>

<?php
$total = 0;

if (!empty($_SESSION['cart'])):

    foreach ($_SESSION['cart'] as $id => $qty):

        $result = mysqli_query(
            $conn,
            "SELECT * FROM products WHERE product_id = $id"
        );

        $p = mysqli_fetch_assoc($result);

        if (!$p) continue;

        $sub = $p['price'] * $qty;
        $total += $sub;

        echo "<p>{$p['product_name']} × $qty = ₹$sub</p>";

    endforeach;

    echo "<h3>Total: ₹$total</h3>";
    echo "<a href='checkout.php'><button>Checkout</button></a>";

else:
    echo "<p>Cart Empty</p>";
endif;
?>

</div>

</body>
</html>
