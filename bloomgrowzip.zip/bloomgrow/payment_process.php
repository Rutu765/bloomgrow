<?php 
include 'config.php'; 
session_start();

if (!isset($_SESSION['user']) || empty($_SESSION['cart'])) {
    header("Location: index.php");
    exit;
}

$user = $_SESSION['user'];
$total = $_SESSION['total'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $query = "INSERT INTO orders (user_email, total_amount, status) 
              VALUES ('$user', '$total', 'Paid')";
    mysqli_query($conn, $query);

    $order_id = mysqli_insert_id($conn);

    unset($_SESSION['cart']);
    unset($_SESSION['total']);

    header("Location: order_success.php?order_id=$order_id");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Payment</title>
</head>
<body>

<h2>Total Amount: ₹<?php echo $total; ?></h2>

<form method="POST">
    <button type="submit">Pay Now</button>
</form>

</body>
</html>