<?php
include 'config.php';

if (!isset($_GET['order_id'])) {
    header("Location: index.php");
    exit;
}

$order_id = $_GET['order_id'];
?>

<!DOCTYPE html>
<html>
<head>
<title>Order Successful</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>

<body background="images/bag.jpg" style="color:white;">

<center>

<h1>🎉 Payment Successful!</h1>
<br>

<p><strong>Order ID:</strong> <?php echo $order_id; ?></p>

<p>Your order has been placed successfully.</p>

<br><br>

<a href="index.php" class="btn" style="color:white;">
    Continue Shopping
</a>

</center>

</body>
</html>